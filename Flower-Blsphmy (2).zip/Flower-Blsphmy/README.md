# Flower Sniper
- A Double purpose use you can set it to Web Sniper and Even Paid Sniper It's your choice!
- although it was not that fast than other known sniper but it can be still able to snipe above 20 depends on how fast your internet is.

join in my Discord Server for guide
[Flower Sniper](https://discord.gg/SjzcTEFQbu)

# Web Configure 
- Change the ``boolean`` to ``false`` to buy Website Item!
![Screenshot_2024-09-15-13-18-52-45_84d3000e3f4017145260f7618db1d683](https://github.com/user-attachments/assets/273dda5f-3d72-45ba-8441-5d3170139bdf)

# Paid Configure 
- Change the ``Boolean`` to ``false`` to buy Paid Website Item
![Screenshot_2024-09-15-13-57-56-07_84d3000e3f4017145260f7618db1d683](https://github.com/user-attachments/assets/fdc4fd13-05a2-4d82-81a1-376bf2d13f23)
- also configure the price below ``boolean`` which is ``prices`` for example you want price of 65 to snipe you can configure it like this ``"prices": [65, 1, 2, 3, 4]`` why needed some number? not just 65? because code was using tuple and it will give error if u set it to one number. Just change the 1,2,3,4 if u want to snipe multiple prices


**Making this more faster soon once i learn more about python**
